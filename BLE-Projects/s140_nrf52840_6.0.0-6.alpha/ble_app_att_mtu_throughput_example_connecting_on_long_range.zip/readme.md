To use this example you need to have two things.
* SDK 14 
* The s140_nrf52840_6.0.0-6.alpha.

This zip file contains a diff of the required modifications to the SDK to make
the ble_app_att_mtu_throughput compile with the new header files.

The steps to compile the example:
1. Download the SDK 14 from:
   http://www.nordicsemi.com/eng/nordic/download_resource/59011/63/48835585/116085
2. Extract the SDK to a location of your wish.
3. Apply the patch provided in this zip: git apply sdk_patch.diff --ignore-space-change --ignore-whitespace
4. Extract the header files from the s140_nrf52840_6.0.0-6.alpha_API\include
   folder to <sdk_location>\components\softdevice\s140\headers folder.
5. Navigate to: examples\ble_central_and_peripheral\experimental\ble_app_att_mtu_throughput\pca10056\s140
6. Compile using your favorite compiler.

Note: When extracting this zip-file over the SDK, you will overwrite some
      files. If this is unwanted, please use a new SDK installation to do it.
      It is also possible to see the modifications in the sdk_diff.patch.

readme.md
sdk_diff.patch
